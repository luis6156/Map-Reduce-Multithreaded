import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.*;

public class Tema2 {
    public static void main(String[] args) {
        int fragmentSize, numberOfFiles, numberOfWorkers;
        HashMap<String, Integer> inputFilesToPosition = new HashMap<>();
        HashMap<String, ArrayList<MapResult>> fileToMaps = new HashMap<>();

        if (args.length < 3) {
            System.err.println("Usage: Tema2 <workers> <in_file> <out_file>");
            return;
        }

        numberOfWorkers = Integer.parseInt(args[0]);

        try (BufferedReader br = new BufferedReader(new FileReader(args[1]))) {
           String line = br.readLine();
           if (line != null) {
               fragmentSize = Integer.parseInt(line);
           } else {
               System.err.println("Input file does not have the allowed format.");
               return;
           }

           line = br.readLine();
           if (line != null) {
                numberOfFiles = Integer.parseInt(line);
           } else {
               System.err.println("Input file does not have the allowed format.");
               return;
           }

           line = br.readLine();
           int position = 0;
           while (line != null) {
               inputFilesToPosition.put(line, position++);
               line = br.readLine();
           }

           ExecutorService tpe = Executors.newFixedThreadPool(numberOfWorkers);
           List<Map> tasks = new ArrayList<>();

            for (HashMap.Entry<String, Integer> filename : inputFilesToPosition.entrySet()) {
                int fileSize = (int) Files.size(Paths.get(filename.getKey()));
                int numberOfFragments = (int) Math.ceil((float)fileSize / fragmentSize);
                for (int j = 0; j < numberOfFragments; ++j) {
                    tasks.add(new Map(filename.getKey(), j * fragmentSize, fragmentSize));
                }
            }

            List<Future<MapResult>> futureMapResults = tpe.invokeAll(tasks);

            for (Future<MapResult> futureMapResult : futureMapResults) {
                MapResult mapResult = futureMapResult.get();
                if (mapResult != null) {
                    if (fileToMaps.containsKey(mapResult.getFilename())) {
                        ArrayList<MapResult> prevMapResults = fileToMaps.get(mapResult.getFilename());
                        prevMapResults.add(mapResult);
                        fileToMaps.put(mapResult.getFilename(), prevMapResults);
                    } else {
                        ArrayList<MapResult> mapResults = new ArrayList<>();
                        mapResults.add(mapResult);
                        fileToMaps.put(mapResult.getFilename(), mapResults);
                    }
                }
            }

            List<Reduce> tasksReduce = new ArrayList<>(numberOfFiles);
            for (HashMap.Entry<String, Integer> filename : inputFilesToPosition.entrySet()) {
                tasksReduce.add(new Reduce(filename.getKey(), fileToMaps.get(filename.getKey())));
            }

            List<Future<ReduceResult>> futureReduceResults = tpe.invokeAll(tasksReduce);
            tpe.shutdown();

            List<ReduceResult> reduceResults = new ArrayList<>();
            for (Future<ReduceResult> futureReduceResult : futureReduceResults) {
                reduceResults.add(futureReduceResult.get());
            }

            reduceResults.sort((o1, o2) -> {
                if (o1.getRank() == o2.getRank()) {
                    return Integer.compare(inputFilesToPosition.get(o1.getFilename()), inputFilesToPosition.get(o2.getFilename()));
                }
                return -Double.compare(o1.getRank(), o2.getRank());
            });

            FileWriter writer = new FileWriter(args[2]);
            for (ReduceResult reduceResult : reduceResults) {
                writer.write(reduceResult.getFilename().substring(reduceResult.getFilename().lastIndexOf("/") + 1) + "," + String.format("%.2f", reduceResult.getRank()) + "," + reduceResult.getMaxLength() + "," + reduceResult.getFrequency() + '\n');
            }
            writer.close();
        } catch (IOException | InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }
}
