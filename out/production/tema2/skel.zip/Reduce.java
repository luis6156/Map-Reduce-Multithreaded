import java.util.*;
import java.util.Map;
import java.util.concurrent.Callable;

public class Reduce implements Callable<ReduceResult> {
    private final String filename;
    private final List<MapResult> mapResults;

    public Reduce(String filename, List<MapResult> mapResults) {
        this.filename = filename;
        this.mapResults = mapResults;
    }

    private int getNthFib2(int N) {
        if (N <= 1)
            return N;
        return getNthFib2(N-1) + getNthFib2(N-2);
    }

    private double getNthFib(int N) {
        return Math.round(Math.pow(((Math.sqrt(5) + 1) / 2), N) / Math.sqrt(5));
    }

    @Override
    public ReduceResult call() throws Exception {
        HashMap<Integer, Integer> lengthToFrequency = new HashMap<>();
        ArrayList<String> words = new ArrayList<>();

        mapResults.forEach(mapResult -> mapResult.getFrequency().forEach((key, value) -> lengthToFrequency.merge(key, value, Integer::sum)));
        mapResults.forEach(mapResult -> Optional.ofNullable(mapResult.getWords()).ifPresent(words::addAll));

        double rank = 0.;
        int totalWords = 0;
        int maxLength = -1;
        int maxLengthFreq = 0;
        for (Map.Entry<Integer, Integer> entry : lengthToFrequency.entrySet()) {
            rank += (getNthFib2(entry.getKey() + 1) * entry.getValue());
            totalWords += entry.getValue();
            if (entry.getKey() > maxLength) {
                maxLength = entry.getKey();
                maxLengthFreq = entry.getValue();
            }
        }
        rank /= totalWords;

        return new ReduceResult(filename, rank, maxLength, maxLengthFreq);
    }
}
