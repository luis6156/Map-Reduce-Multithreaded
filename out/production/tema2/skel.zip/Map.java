import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;

public class Map implements Callable<MapResult> {
    private final String name;
    private final int offset;
    private int fragmentSize;

    public Map(String name, int offset, int fragmentSize) {
        this.name = name;
        this.offset = offset;
        this.fragmentSize = fragmentSize;
    }

    private boolean isAlphaNumeric(char c) {
        return Character.isDigit(c) || Character.isLetter(c);
    }

    @Override
    public MapResult call() {
        HashMap<Integer, Integer> lengthToFrequency = new HashMap<>();
        HashMap<Integer, ArrayList<String>> lengthToWords = new HashMap<>();
        int max = -1;
        try (BufferedReader br = new BufferedReader(new FileReader(name))) {
            StringBuilder sb = new StringBuilder();
            long r = fragmentSize;
            int numberOfChars = 0;

            if (offset != 0) {
                r = br.skip(offset - 1);
                if (r == 0) {
                    return null;
                }
                while (true) {
                    if (!isAlphaNumeric((char) br.read())) {
                        break;
                    } else {
                        --fragmentSize;
                    }
                }
            }

            for (int i = 0; i < fragmentSize; ++i) {
                r = br.read();
                if (r == -1 && numberOfChars != 0) {
                    ArrayList<String> words;
                    if (lengthToFrequency.containsKey(numberOfChars)) {
                        int prevFreq = lengthToFrequency.get(numberOfChars);
                        words = lengthToWords.get(numberOfChars);
                        words.add(sb.toString());
                        lengthToFrequency.put(numberOfChars, prevFreq + 1);
                    } else {
                        lengthToFrequency.put(numberOfChars, 1);
                        words = new ArrayList<>();
                        words.add(sb.toString());
                    }

                    lengthToWords.put(numberOfChars, words);
                    if (numberOfChars > max) {
                        max = numberOfChars;
                    }
                    break;
                } else if (isAlphaNumeric((char)r)) {
                    sb.append((char)r);
                    ++numberOfChars;
                } else if (numberOfChars != 0) {
                    ArrayList<String> words;
                    if (lengthToFrequency.containsKey(numberOfChars)) {
                        int prevFreq = lengthToFrequency.get(numberOfChars);
                        words = lengthToWords.get(numberOfChars);
                        words.add(sb.toString());
                        lengthToFrequency.put(numberOfChars, prevFreq + 1);
                    } else {
                        lengthToFrequency.put(numberOfChars, 1);
                        words = new ArrayList<>();
                        words.add(sb.toString());
                    }

                    lengthToWords.put(numberOfChars, words);
                    if (numberOfChars > max) {
                        max = numberOfChars;
                    }
                    numberOfChars = 0;
                    sb.setLength(0);
                }
            }

            if (r != -1 && numberOfChars != 0) {
                while (true) {
                    r = br.read();
                    if (r == -1 && numberOfChars != 0) {
                        ArrayList<String> words;
                        if (lengthToFrequency.containsKey(numberOfChars)) {
                            int prevFreq = lengthToFrequency.get(numberOfChars);
                            words = lengthToWords.get(numberOfChars);
                            words.add(sb.toString());
                            lengthToFrequency.put(numberOfChars, prevFreq + 1);
                        } else {
                            lengthToFrequency.put(numberOfChars, 1);
                            words = new ArrayList<>();
                            words.add(sb.toString());
                        }

                        lengthToWords.put(numberOfChars, words);
                        if (numberOfChars > max) {
                            max = numberOfChars;
                        }
                        break;
                    } else if (isAlphaNumeric((char)r)) {
                        sb.append((char)r);
                        ++numberOfChars;
                    } else if (numberOfChars != 0) {
                        ArrayList<String> words;
                        if (lengthToFrequency.containsKey(numberOfChars)) {
                            int prevFreq = lengthToFrequency.get(numberOfChars);
                            words = lengthToWords.get(numberOfChars);
                            words.add(sb.toString());
                            lengthToFrequency.put(numberOfChars, prevFreq + 1);
                        } else {
                            lengthToFrequency.put(numberOfChars, 1);
                            words = new ArrayList<>();
                            words.add(sb.toString());
                        }

                        lengthToWords.put(numberOfChars, words);
                        if (numberOfChars > max) {
                            max = numberOfChars;
                        }
                        break;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return new MapResult(name, lengthToFrequency, lengthToWords.get(max));
    }
}
